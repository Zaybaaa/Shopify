<h3 align="center">
Hi there, I'm Shivam</a> 👋
</h3>

I love the entire process of developing creative websites. I love the challenge of finding caches and spending time to meet new people. 


# Shopify Clone

![ineuro, lco](https://img.shields.io/badge/iNeuron-LCO-blue)
![hitesh choudhary](https://img.shields.io/badge/Hitesh--Choudhary-Full--stack--JS--bootcamp-red)

![HTML & CSS](https://img.shields.io/badge/HTML-CSS-orange)
![Live class](https://img.shields.io/badge/LIVE--CLASS-PROJECT--9-lightgrey)



---

## Shopifty CLONE

-   Skills Gained in this project
    -  Gained more knowledge about tailwindcss
    -  Learned to use tailwindcss in less time efficiently.
      
     

---

## Time taken to finish this project

-   7 hour taken to complete it.

## Screenshot

![](./home%20page.png)